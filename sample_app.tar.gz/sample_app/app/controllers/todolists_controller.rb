class TodolistsController < ApplicationController

   def new
     # Viewへ渡すためのインスタンス変数に空のモデルオブジェクト
     @list = List.new
   end

   def create
     # データを新規登録するためのインスタンス生成
     list = List.new(list_params)
     # listインスタンスでは、Listのメソッドでnewが呼び出され、
     # 引数でlist_paramsが呼び出されている

     # データをデータベースに保存するためのsaveメソッド
     list.save

     # トップ画面へリダイレクト
     redirect_to todolist_path(list.id)
   end

   def index
     @lists = List.all
     @list = List.new
   end

   def show
     @list = List.find(params[:id])
   end

   def edit
     @list = List.find(params[:id])
   end

   def update
     list = List.find(params[:id])
     list.update(list_params)
     redirect_to todolist_path(list.id)
   end

   def destroy
       list = List.find(params[:id])
       list.destroy
       redirect_to todolists_path
   end


   private
     # ストロングパラメーター
     # フォームからデータを送信するときは、マスアサインメント脆弱性という
     # セキュリティ上の問題があり、を防ぐ。（データ送信時に不正なリクエストによって、
     # 予期しない値を変更されてしまう脆弱性）
     def list_params
     # フォームで入力されたデータを受け取っている。
       params.require(:list).permit(:title, :body, :image)
       # paramsはRailsで送られてきた値を受け取るためのメソッド
       # requireでデータのオブジェクト名（ここでは:list）を指定、
       # permitでキー（:title,:body）を指定
       # これによりlist_paramsの中にフォームで入力されたデータが格納される
     end

end
