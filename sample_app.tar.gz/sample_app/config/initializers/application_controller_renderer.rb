# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = '93a66f1c6e93921f8ac70460851c4bed6735480fde27708112d2c5fd4ef860620ddcef9625fbb7035c57d0aa7bc097d1e8beda86d0a7a8133eeced622db010d7'
